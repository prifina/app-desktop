export class Bank {    
    public id: string;
    public name : string;
    public type: string;
    public city: string;
    public state: string;
    public zipCode : string;

    constructor(){}
 }
